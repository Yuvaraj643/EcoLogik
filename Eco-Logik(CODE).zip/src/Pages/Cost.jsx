import React from 'react';
import Sidebar from '../Components/Sidebar/Sidebar'
import CostDashboard from '../Components/CostDashboard/CostDashboard';


const Cost = () => {
  return (
    <>
    <Sidebar />
    <CostDashboard />
    </>
  )
}

export default Cost